# -*- coding: utf-8 -*-
import sys
from PyQt5 import QtWidgets, QPixmap
from MainWindow import Ui_MainWindow
 

class MainWindow(QtWidgets.QMainWindow,  Ui_MainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setupUi(self)

    def on_button_open_clicked(self):
        self.label.setText("打开按钮按下")
        self.setWindowTitle("打开")

    def on_button_save_clicked(self):
        self.label.setText("保存 按钮按下")
        self.setWindowTitle("保存")

    def on_button_1_clicked(self):
        self.label.setText("彩->灰 按钮按下")
        self.setWindowTitle("彩->灰")

    def on_button_2_clicked(self):
        self.label.setText("灰->二 按钮按下")
        self.setWindowTitle("灰->二")

    def on_button_3_clicked(self):
        self.label.setText("几何变换 按钮按下")
        self.setWindowTitle("几何变换")

    def on_button_4_clicked(self):
        self.label.setText("去噪 按钮按下")
        self.setWindowTitle("去噪")

    def on_button_5_clicked(self):
        self.label.setText("push 按钮按下")
        self.setWindowTitle("push")

    def on_button_6_clicked(self):
        self.label.setText("边缘提取 按钮按下")
        self.setWindowTitle("边缘提取")

    def on_button_7_clicked(self):
        self.label.setText("加躁 按钮按下")
        self.setWindowTitle("加躁")

    def on_button_8_clicked(self):
        self.label.setText("退出 按钮按下")
        self.setWindowTitle("退出")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
   # w = MainWindow()
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())
